Windows build for krx-pool-miner v0.2.1-GPU-0.7

This package currently contains the CPU-only executable.
GPU plugin DLLs are not bundled in this release build.
